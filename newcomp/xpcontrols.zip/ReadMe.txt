The packages

  XPControls
  XPControlsREG

and the components

  TXPAnimate
  TXPCheckBox
  TXPCheckListBox
  TXPGroupBox
  TXPListView
  TXPPageControl
  TXPRadioButton
  TXPStatusBar
  TXPThemeAPI
  TXPToolBar
  TXPTrackBar

are freeware to everybody.

The software is given as is without any warranty.
Please note that we will give no support to anybody concerning this software.

Only copyright owner is and will remain

  micro dynamics GmbH
  Uferstr. 14
  D-50996 Cologne
  GERMANY


New in Version 2.20 / 2002-06-30

1. separation of designtime-only code into second package

2. new components TXPStatusBar and TXPToolBar
   the incorrect behavior of original Delphi ToolButton component
   after Mouseclicks with tbsDropDown-style is solved

3. new package set for Delphi 6

